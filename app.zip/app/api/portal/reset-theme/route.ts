import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { verifyToken } from '@/lib/auth';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('token')?.value;
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userId = await verifyToken(token);
    if (!userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { portal: true }
    });

    if (!user || !user.portal) {
      return NextResponse.json({ error: 'Portal not found' }, { status: 404 });
    }

    // Reset to default values
    const updatedPortal = await prisma.portal.update({
      where: { id: user.portal.id },
      data: {
        publicTemplateId: 'template1',
        publicPrimaryColor: '#f5f5f5',
        publicBackgroundType: 'color',
        publicGradientStart: null,
        publicGradientEnd: null,
        publicBackgroundImage: null,
        publicTextColor: null,
        publicFontFamily: 'font-sans',
        adminTemplateId: 'template1',
        adminPrimaryColor: '#f5f5f5',
        adminBackgroundType: 'color',
        adminGradientStart: null,
        adminGradientEnd: null,
        adminBackgroundImage: null,
        adminTextColor: null,
        adminFontFamily: 'font-sans',
      }
    });

    return NextResponse.json({ success: true, portal: updatedPortal });
  } catch (error) {
    console.error('Reset theme error:', error);
    return NextResponse.json({ error: 'Failed to reset theme' }, { status: 500 });
  }
}
-- AlterTable
ALTER TABLE "Portal" ALTER COLUMN "backgroundImage" SET DEFAULT 'images/default-bg.jpg';
